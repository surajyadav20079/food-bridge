# FoodBridge 🍃

FoodBridge is a food donation platform concept that connects food donors with NGOs and volunteers. It aims to reduce food waste and help communities by making surplus food easier to share.

## Features

- Responsive landing page
- Available food donation cards
- Food donation form
- Login interface with role selection
- Pickup request interaction
- Admin dashboard preview

## Technologies Used

- HTML5
- CSS3
- JavaScript

## Getting Started

### Run locally

1. Download or clone this repository.
2. Open `index.html` in a web browser.

No build tools or package installation are required for this frontend demo.

## GitHub Pages Deployment

1. Push the project files to a GitHub repository.
2. Open the repository's **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the `main` branch and `/ (root)` folder, then save.
5. Wait for GitHub Pages to publish the site.

## Project Status

This repository contains the frontend demonstration. The login, donation submission, and pickup request interactions currently use browser prompts/alerts; they do not save data to a server or provide real authentication. The food listings and dashboard figures are sample content.

## External Assets

Some food images are loaded from Unsplash, so an internet connection is needed to display those images.

## Contributing

Suggestions and improvements are welcome. You can open an issue or submit a pull request.
